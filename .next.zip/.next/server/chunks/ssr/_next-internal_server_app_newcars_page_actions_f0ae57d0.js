module.exports=[95196,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_newcars_page_actions_f0ae57d0.js.map