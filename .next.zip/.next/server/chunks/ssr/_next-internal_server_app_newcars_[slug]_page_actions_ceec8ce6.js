module.exports=[65962,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_newcars_%5Bslug%5D_page_actions_ceec8ce6.js.map