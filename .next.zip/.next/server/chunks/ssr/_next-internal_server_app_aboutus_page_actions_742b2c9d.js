module.exports=[97003,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_aboutus_page_actions_742b2c9d.js.map