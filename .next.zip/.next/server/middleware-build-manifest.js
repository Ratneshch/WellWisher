globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/78ae4a069704c0ec.js",
    "static/chunks/330faf687a17f9e8.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/c645af7d6b65f73e.js",
    "static/chunks/turbopack-7ab1b1310f82e0cc.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];