(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_hi_index_mjs_c1b692d7._.js",
  "static/chunks/node_modules_react-icons_ri_index_mjs_150b4c77._.js",
  "static/chunks/node_modules_react-icons_io_index_mjs_7f31b177._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_next_a62874fb._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_6442105e._.js",
  "static/chunks/src_components_58d1ec4c._.js"
],
    source: "dynamic"
});
