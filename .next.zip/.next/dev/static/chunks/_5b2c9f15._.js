(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/newcars/[slug]/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/newcars/[slug]/page.js
__turbopack_context__.s([
    "default",
    ()=>CarDetailsPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$tatacars$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/tatacars.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function CarDetailsPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(124);
    if ($[0] !== "bea1b9e9fbf5435756eff10e80bddae182124163f9dc3afbdef64aef3603d383") {
        for(let $i = 0; $i < 124; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bea1b9e9fbf5435756eff10e80bddae182124163f9dc3afbdef64aef3603d383";
    }
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const slug = params?.slug;
    let t0;
    if ($[1] !== slug) {
        t0 = (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$tatacars$2e$json__$28$json$29$__["default"] || []).find({
            "CarDetailsPage[(anonymous)()]": (c)=>c && String(c.slug) === String(slug)
        }["CarDetailsPage[(anonymous)()]"]);
        $[1] = slug;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const car = t0;
    let t1;
    if ($[3] !== car?.specifications) {
        t1 = car?.specifications || {};
        $[3] = car?.specifications;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    const specs = t1;
    if (!car) {
        const t2 = slug || "(no slug provided)";
        let t3;
        if ($[5] !== t2) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "min-h-screen flex items-center justify-center bg-slate-950 px-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-slate-400 text-center text-sm md:text-base",
                    children: [
                        "Car details not found for",
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                            className: "text-slate-100",
                            children: t2
                        }, void 0, false, {
                            fileName: "[project]/src/app/newcars/[slug]/page.js",
                            lineNumber: 43,
                            columnNumber: 187
                        }, this),
                        "."
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/newcars/[slug]/page.js",
                    lineNumber: 43,
                    columnNumber: 94
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/newcars/[slug]/page.js",
                lineNumber: 43,
                columnNumber: 12
            }, this);
            $[5] = t2;
            $[6] = t3;
        } else {
            t3 = $[6];
        }
        return t3;
    }
    let t2;
    if ($[7] !== car.image || $[8] !== car.name) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: car.image,
            alt: car.name,
            className: "absolute inset-0 w-full h-full object-cover scale-110 blur-[2px] opacity-70"
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 53,
            columnNumber: 10
        }, this);
        $[7] = car.image;
        $[8] = car.name;
        $[9] = t2;
    } else {
        t2 = $[9];
    }
    let t3;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 bg-gradient-to-r from-black/50 via-black/30 to-black/50"
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 62,
            columnNumber: 10
        }, this);
        $[10] = t3;
    } else {
        t3 = $[10];
    }
    let t4;
    if ($[11] !== car.name) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-3xl md:text-5xl lg:text-6xl font-black tracking-tight text-gray-50",
            children: car.name
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 69,
            columnNumber: 10
        }, this);
        $[11] = car.name;
        $[12] = t4;
    } else {
        t4 = $[12];
    }
    let t5;
    if ($[13] !== car.tagline) {
        t5 = car.tagline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xl md:text-2xl text-slate-300 max-w-md",
            children: car.tagline
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 77,
            columnNumber: 25
        }, this);
        $[13] = car.tagline;
        $[14] = t5;
    } else {
        t5 = $[14];
    }
    let t6;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-wrap gap-3 pt-3 justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/contactus",
                className: "px-5 py-2.5 rounded-full bg-amber-500 text-sm font-semibold text-slate-900  hover:bg-amber-400 transition cursor-pointer",
                children: "Enquiry Now"
            }, void 0, false, {
                fileName: "[project]/src/app/newcars/[slug]/page.js",
                lineNumber: 85,
                columnNumber: 68
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 85,
            columnNumber: 10
        }, this);
        $[15] = t6;
    } else {
        t6 = $[15];
    }
    let t7;
    if ($[16] !== t4 || $[17] !== t5) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative top-20 md:top-0 max-w-6xl mx-auto h-full flex flex-col md:flex-row items-center justify-between px-6 md:px-8",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-xl space-y-4 md:space-y-5 mx-auto text-center ",
                children: [
                    t4,
                    t5,
                    t6
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/newcars/[slug]/page.js",
                lineNumber: 92,
                columnNumber: 145
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 92,
            columnNumber: 10
        }, this);
        $[16] = t4;
        $[17] = t5;
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    let t8;
    if ($[19] !== t2 || $[20] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: " relative h-[360px] md:h-[450px] w-full overflow-hidden bg-gradient-to-b from-slate-900 via-slate-500 to-black",
            children: [
                t2,
                t3,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 101,
            columnNumber: 10
        }, this);
        $[19] = t2;
        $[20] = t7;
        $[21] = t8;
    } else {
        t8 = $[21];
    }
    const t9 = `relative flex items-center justify-center w-full md:w-5/10 min-h-[260px] p-7 md:p-8 ${car.accentBg} bg-gradient-to-br from-amber-50 via-orange-50 to-slate-50`;
    let t10;
    let t11;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 opacity-25 mix-blend-screen bg-[radial-gradient(circle_at_top,#ffffff33,transparent_55%),radial-gradient(circle_at_bottom,#0000001a,transparent_55%)]"
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 112,
            columnNumber: 11
        }, this);
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute -right-8 top-0 bottom-0 w-16 hidden md:block"
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 113,
            columnNumber: 11
        }, this);
        $[22] = t10;
        $[23] = t11;
    } else {
        t10 = $[22];
        t11 = $[23];
    }
    const t12 = car.imageCard || car.image;
    let t13;
    if ($[24] !== car.name || $[25] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: t12,
            alt: car.name,
            className: "relative z-10 w-full max-w-sm object-contain drop-shadow-[0_18px_45px_rgba(15,23,42,0.25)]"
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 123,
            columnNumber: 11
        }, this);
        $[24] = car.name;
        $[25] = t12;
        $[26] = t13;
    } else {
        t13 = $[26];
    }
    let t14;
    if ($[27] !== car.name) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-5 left-6 text-[16px] font-semibold tracking-[0.25em] uppercase text-black",
            children: car.name
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 132,
            columnNumber: 11
        }, this);
        $[27] = car.name;
        $[28] = t14;
    } else {
        t14 = $[28];
    }
    let t15;
    if ($[29] !== t13 || $[30] !== t14 || $[31] !== t9) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t9,
            children: [
                t10,
                t11,
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 140,
            columnNumber: 11
        }, this);
        $[29] = t13;
        $[30] = t14;
        $[31] = t9;
        $[32] = t15;
    } else {
        t15 = $[32];
    }
    let t16;
    if ($[33] !== car.name) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-2xl md:text-4xl font-black tracking-tight text-slate-900",
            children: car.name
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 150,
            columnNumber: 11
        }, this);
        $[33] = car.name;
        $[34] = t16;
    } else {
        t16 = $[34];
    }
    let t17;
    if ($[35] !== car.tagline) {
        t17 = car.tagline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm md:text-base text-slate-800 mt-2 max-w-lg ",
            children: car.tagline
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 158,
            columnNumber: 26
        }, this);
        $[35] = car.tagline;
        $[36] = t17;
    } else {
        t17 = $[36];
    }
    let t18;
    if ($[37] !== t16 || $[38] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-end",
            children: [
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 166,
            columnNumber: 11
        }, this);
        $[37] = t16;
        $[38] = t17;
        $[39] = t18;
    } else {
        t18 = $[39];
    }
    let t19;
    if ($[40] !== car.description) {
        t19 = car.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm md:text-[15px] leading-relaxed text-slate-700 max-w-xl",
            children: car.description
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 175,
            columnNumber: 30
        }, this);
        $[40] = car.description;
        $[41] = t19;
    } else {
        t19 = $[41];
    }
    let t20;
    if ($[42] !== specs.safety) {
        t20 = specs.safety && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Badge, {
            children: specs.safety
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 183,
            columnNumber: 27
        }, this);
        $[42] = specs.safety;
        $[43] = t20;
    } else {
        t20 = $[43];
    }
    let t21;
    if ($[44] !== specs.power) {
        t21 = specs.power && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Badge, {
            children: specs.power
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 191,
            columnNumber: 26
        }, this);
        $[44] = specs.power;
        $[45] = t21;
    } else {
        t21 = $[45];
    }
    let t22;
    if ($[46] !== specs.mileage) {
        t22 = specs.mileage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Badge, {
            children: [
                specs.mileage,
                " mileage"
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 199,
            columnNumber: 28
        }, this);
        $[46] = specs.mileage;
        $[47] = t22;
    } else {
        t22 = $[47];
    }
    let t23;
    if ($[48] !== specs.transmission) {
        t23 = specs.transmission && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Badge, {
            children: specs.transmission
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 207,
            columnNumber: 33
        }, this);
        $[48] = specs.transmission;
        $[49] = t23;
    } else {
        t23 = $[49];
    }
    let t24;
    if ($[50] !== t20 || $[51] !== t21 || $[52] !== t22 || $[53] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-wrap gap-2 pt-1 text-[11px] md:text-[12px] md:justify-end justify-center",
            children: [
                t20,
                t21,
                t22,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 215,
            columnNumber: 11
        }, this);
        $[50] = t20;
        $[51] = t21;
        $[52] = t22;
        $[53] = t23;
        $[54] = t24;
    } else {
        t24 = $[54];
    }
    let t25;
    if ($[55] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xs uppercase tracking-[0.25em] text-slate-800",
            children: "Starting ex-showroom"
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 226,
            columnNumber: 11
        }, this);
        $[55] = t25;
    } else {
        t25 = $[55];
    }
    let t26;
    if ($[56] !== car.exShowroom) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-2xl md:text-3xl font-black text-black mt-1",
            children: [
                "₹ ",
                car.exShowroom
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 233,
            columnNumber: 11
        }, this);
        $[56] = car.exShowroom;
        $[57] = t26;
    } else {
        t26 = $[57];
    }
    let t27;
    if ($[58] !== car.onRoad_Mumbai) {
        t27 = car.onRoad_Mumbai && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xs text-slate-700 mt-1",
            children: [
                "On-road Mumbai from",
                " ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "font-medium text-slate-800",
                    children: car.onRoad_Mumbai
                }, void 0, false, {
                    fileName: "[project]/src/app/newcars/[slug]/page.js",
                    lineNumber: 241,
                    columnNumber: 99
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 241,
            columnNumber: 32
        }, this);
        $[58] = car.onRoad_Mumbai;
        $[59] = t27;
    } else {
        t27 = $[59];
    }
    let t28;
    if ($[60] !== t26 || $[61] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t25,
                t26,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 249,
            columnNumber: 11
        }, this);
        $[60] = t26;
        $[61] = t27;
        $[62] = t28;
    } else {
        t28 = $[62];
    }
    let t29;
    if ($[63] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-center flex-wrap gap-3",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/contactus",
                className: "px-5 py-2.5 rounded-full bg-amber-500 text-xs md:text-sm font-semibold text-black hover:bg-amber-400  transition cursor-pointer ",
                children: "Pre-Book →"
            }, void 0, false, {
                fileName: "[project]/src/app/newcars/[slug]/page.js",
                lineNumber: 258,
                columnNumber: 64
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 258,
            columnNumber: 11
        }, this);
        $[63] = t29;
    } else {
        t29 = $[63];
    }
    let t30;
    if ($[64] !== t28) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col sm:items-end sm:justify-between gap-4 pt-2",
            children: [
                t28,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 265,
            columnNumber: 11
        }, this);
        $[64] = t28;
        $[65] = t30;
    } else {
        t30 = $[65];
    }
    let t31;
    if ($[66] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[10px] text-slate-400 mt-1",
            children: "Prices shown are indicative. Final offer price will be shared by your nearest dealer."
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 273,
            columnNumber: 11
        }, this);
        $[66] = t31;
    } else {
        t31 = $[66];
    }
    let t32;
    if ($[67] !== t18 || $[68] !== t19 || $[69] !== t24 || $[70] !== t30) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full md:w-7/12 p-6 md:p-10 lg:p-12 flex flex-col md:text-end md:items-end gap-5 text-center items-center ",
            children: [
                t18,
                t19,
                t24,
                t30,
                t31
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 280,
            columnNumber: 11
        }, this);
        $[67] = t18;
        $[68] = t19;
        $[69] = t24;
        $[70] = t30;
        $[71] = t32;
    } else {
        t32 = $[71];
    }
    let t33;
    if ($[72] !== t15 || $[73] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "bg-linear-to-br from-slate-50 via-white to-slate-100 border border-slate-200/80 rounded-3xl shadow-[0_18px_60px_rgba(15,23,42,0.16)] overflow-hidden backdrop-blur-xl",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row",
                children: [
                    t15,
                    t32
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/newcars/[slug]/page.js",
                lineNumber: 291,
                columnNumber: 198
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 291,
            columnNumber: 11
        }, this);
        $[72] = t15;
        $[73] = t32;
        $[74] = t33;
    } else {
        t33 = $[74];
    }
    let t34;
    if ($[75] === Symbol.for("react.memo_cache_sentinel")) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-between gap-3 ",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: " mx-auto ",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl md:text-2xl font-bold tracking-[0.18em]  uppercase text-slate-900 ml-3 md:mr-108",
                        children: "Specifications"
                    }, void 0, false, {
                        fileName: "[project]/src/app/newcars/[slug]/page.js",
                        lineNumber: 300,
                        columnNumber: 96
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-slate-700 mt-1 md:ml-3",
                        children: "Engine, performance, dimensions and more"
                    }, void 0, false, {
                        fileName: "[project]/src/app/newcars/[slug]/page.js",
                        lineNumber: 300,
                        columnNumber: 220
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/newcars/[slug]/page.js",
                lineNumber: 300,
                columnNumber: 69
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 300,
            columnNumber: 11
        }, this);
        $[75] = t34;
    } else {
        t34 = $[75];
    }
    let t35;
    if ($[76] !== specs.mileage) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SpecItem, {
            label: "Mileage-",
            value: specs.mileage
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 307,
            columnNumber: 11
        }, this);
        $[76] = specs.mileage;
        $[77] = t35;
    } else {
        t35 = $[77];
    }
    let t36;
    if ($[78] !== specs.engine) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SpecItem, {
            label: "Engine-",
            value: specs.engine
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 315,
            columnNumber: 11
        }, this);
        $[78] = specs.engine;
        $[79] = t36;
    } else {
        t36 = $[79];
    }
    let t37;
    if ($[80] !== specs.safety) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SpecItem, {
            label: "Safety-",
            value: specs.safety
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 323,
            columnNumber: 11
        }, this);
        $[80] = specs.safety;
        $[81] = t37;
    } else {
        t37 = $[81];
    }
    let t38;
    if ($[82] !== specs.fuelType) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SpecItem, {
            label: "Fuel Type-",
            value: specs.fuelType
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 331,
            columnNumber: 11
        }, this);
        $[82] = specs.fuelType;
        $[83] = t38;
    } else {
        t38 = $[83];
    }
    let t39;
    if ($[84] !== specs.transmission) {
        t39 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SpecItem, {
            label: "Transmission-",
            value: specs.transmission
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 339,
            columnNumber: 11
        }, this);
        $[84] = specs.transmission;
        $[85] = t39;
    } else {
        t39 = $[85];
    }
    let t40;
    if ($[86] !== specs.seatingCapacity) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SpecItem, {
            label: "Seating Capacity-",
            value: specs.seatingCapacity
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 347,
            columnNumber: 11
        }, this);
        $[86] = specs.seatingCapacity;
        $[87] = t40;
    } else {
        t40 = $[87];
    }
    let t41;
    if ($[88] !== specs.fuelTank) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SpecItem, {
            label: "Fuel Tank-",
            value: specs.fuelTank
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 355,
            columnNumber: 11
        }, this);
        $[88] = specs.fuelTank;
        $[89] = t41;
    } else {
        t41 = $[89];
    }
    let t42;
    if ($[90] !== specs.tyreSize) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SpecItem, {
            label: "Tyre Size-",
            value: specs.tyreSize
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 363,
            columnNumber: 11
        }, this);
        $[90] = specs.tyreSize;
        $[91] = t42;
    } else {
        t42 = $[91];
    }
    let t43;
    if ($[92] !== t35 || $[93] !== t36 || $[94] !== t37 || $[95] !== t38 || $[96] !== t39 || $[97] !== t40 || $[98] !== t41 || $[99] !== t42) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
            className: "grid grid-cols-1 md:grid-cols-2 space-y-4 gap-x-5 text-[14px] md:text-[16px] text-slate-900 font-medium text-center md:text-start",
            children: [
                t35,
                t36,
                t37,
                t38,
                t39,
                t40,
                t41,
                t42
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 371,
            columnNumber: 11
        }, this);
        $[92] = t35;
        $[93] = t36;
        $[94] = t37;
        $[95] = t38;
        $[96] = t39;
        $[97] = t40;
        $[98] = t41;
        $[99] = t42;
        $[100] = t43;
    } else {
        t43 = $[100];
    }
    let t44;
    if ($[101] !== specs.specsSource) {
        t44 = specs.specsSource && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-[11px] text-slate-600 text-center md:text-start",
            children: [
                "Specifications as shared by ",
                specs.specsSource,
                "."
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 386,
            columnNumber: 32
        }, this);
        $[101] = specs.specsSource;
        $[102] = t44;
    } else {
        t44 = $[102];
    }
    let t45;
    if ($[103] !== t43 || $[104] !== t44) {
        t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-9",
            children: [
                t34,
                t43,
                t44
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 394,
            columnNumber: 11
        }, this);
        $[103] = t43;
        $[104] = t44;
        $[105] = t45;
    } else {
        t45 = $[105];
    }
    let t46;
    if ($[106] !== car.imageCard || $[107] !== car.name) {
        t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: car.imageCard,
                alt: car.name,
                className: "w-full h-full object-contain p-4"
            }, void 0, false, {
                fileName: "[project]/src/app/newcars/[slug]/page.js",
                lineNumber: 403,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 403,
            columnNumber: 11
        }, this);
        $[106] = car.imageCard;
        $[107] = car.name;
        $[108] = t46;
    } else {
        t46 = $[108];
    }
    let t47;
    if ($[109] !== t45 || $[110] !== t46) {
        t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid md:grid-cols-2 gap-10 items-center",
            children: [
                t45,
                t46
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 412,
            columnNumber: 11
        }, this);
        $[109] = t45;
        $[110] = t46;
        $[111] = t47;
    } else {
        t47 = $[111];
    }
    let t48;
    if ($[112] !== car.name || $[113] !== car.ytlink) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "w-full mt-10",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full max-w-7xl mx-auto rounded-xl overflow-hidden shadow-[0_20px_60px_rgba(15,23,42,0.12)]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative w-full h-64 sm:h-80 md:h-96 lg:h-[500px]",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                        src: car.ytlink,
                        className: "absolute inset-0 w-full h-full rounded-xl",
                        title: car.name,
                        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                        allowFullScreen: true
                    }, void 0, false, {
                        fileName: "[project]/src/app/newcars/[slug]/page.js",
                        lineNumber: 421,
                        columnNumber: 222
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/newcars/[slug]/page.js",
                    lineNumber: 421,
                    columnNumber: 155
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/newcars/[slug]/page.js",
                lineNumber: 421,
                columnNumber: 45
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 421,
            columnNumber: 11
        }, this);
        $[112] = car.name;
        $[113] = car.ytlink;
        $[114] = t48;
    } else {
        t48 = $[114];
    }
    let t49;
    if ($[115] !== t47 || $[116] !== t48) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "bg-white border border-slate-300 rounded-3xl p-6 md:p-10 shadow-[0_20px_60px_rgba(15,23,42,0.12)]",
            children: [
                t47,
                t48
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 430,
            columnNumber: 11
        }, this);
        $[115] = t47;
        $[116] = t48;
        $[117] = t49;
    } else {
        t49 = $[117];
    }
    let t50;
    if ($[118] !== t33 || $[119] !== t49) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-6xl mx-auto px-4 lg:px-6 pb-12 space-y-10 -mt-10 md:-mt-14 relative z-10",
            children: [
                t33,
                t49
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 439,
            columnNumber: 11
        }, this);
        $[118] = t33;
        $[119] = t49;
        $[120] = t50;
    } else {
        t50 = $[120];
    }
    let t51;
    if ($[121] !== t50 || $[122] !== t8) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "min-h-screen text-black",
            children: [
                t8,
                t50
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 448,
            columnNumber: 11
        }, this);
        $[121] = t50;
        $[122] = t8;
        $[123] = t51;
    } else {
        t51 = $[123];
    }
    return t51;
}
_s(CarDetailsPage, "+jVsTcECDRo3yq2d7EQxlN9Ixog=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = CarDetailsPage;
function SpecItem(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "bea1b9e9fbf5435756eff10e80bddae182124163f9dc3afbdef64aef3603d383") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bea1b9e9fbf5435756eff10e80bddae182124163f9dc3afbdef64aef3603d383";
    }
    const { label, value } = t0;
    if (!value) {
        return null;
    }
    let t1;
    if ($[1] !== label) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
            className: "text-[15px] uppercase  text-slate-900",
            children: label
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 474,
            columnNumber: 10
        }, this);
        $[1] = label;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== value) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
            className: "font-medium text-slate-800 mt-0.5",
            children: value
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 482,
            columnNumber: 10
        }, this);
        $[3] = value;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== t1 || $[6] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col",
            children: [
                t1,
                t2
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 490,
            columnNumber: 10
        }, this);
        $[5] = t1;
        $[6] = t2;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    return t3;
}
_c1 = SpecItem;
function Badge(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "bea1b9e9fbf5435756eff10e80bddae182124163f9dc3afbdef64aef3603d383") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bea1b9e9fbf5435756eff10e80bddae182124163f9dc3afbdef64aef3603d383";
    }
    const { children } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "h-1.5 w-1.5 rounded-full bg-emerald-400"
        }, void 0, false, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 512,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== children) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-white border border-black text-slate-900 text-[11px] md:text-[12px] font-medium shadow-[0_8px_18px_rgba(15,23,42,0.18)]",
            children: [
                t1,
                children
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/newcars/[slug]/page.js",
            lineNumber: 519,
            columnNumber: 10
        }, this);
        $[2] = children;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c2 = Badge;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "CarDetailsPage");
__turbopack_context__.k.register(_c1, "SpecItem");
__turbopack_context__.k.register(_c2, "Badge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/next/navigation.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/navigation.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=_5b2c9f15._.js.map