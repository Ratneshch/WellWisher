(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/aboutus/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AboutUsPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function AboutUsPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(28);
    if ($[0] !== "bd3d147c51650fd5e1a9c2ad178cbeaf1685ee82bd639b178f5f35f46170df74") {
        for(let $i = 0; $i < 28; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bd3d147c51650fd5e1a9c2ad178cbeaf1685ee82bd639b178f5f35f46170df74";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [
            "/showroom-1.jpeg",
            "/showroom-2.jpg",
            "/showroom-3.jpg"
        ];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const showroomImages = t0;
    const [index, setIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    let t1;
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "AboutUsPage[useEffect()]": ()=>{
                const t = setInterval({
                    "AboutUsPage[useEffect() > setInterval()]": ()=>{
                        setIndex({
                            "AboutUsPage[useEffect() > setInterval() > setIndex()]": (i)=>(i + 1) % showroomImages.length
                        }["AboutUsPage[useEffect() > setInterval() > setIndex()]"]);
                    }
                }["AboutUsPage[useEffect() > setInterval()]"], 4000);
                return ()=>clearInterval(t);
            }
        })["AboutUsPage[useEffect()]"];
        t2 = [];
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            src: "/shbanner.jpg",
            className: "w-full object-cover h-full",
            alt: "About Us Banner"
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 49,
            columnNumber: 10
        }, this);
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 bg-linear-to-b from-black/10 via-transparent to-black/70"
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 50,
            columnNumber: 10
        }, this);
        $[4] = t3;
        $[5] = t4;
    } else {
        t3 = $[4];
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative h-[350px] w-full mb-5 rounded-9xl",
            children: [
                t3,
                t4,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 items-center justify-center mt-5 flex flex-col",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl md:text-5xl font-bold text-white drop-shadow-[0_4px_6px_rgba(0,0,0,0.6)]",
                            children: "About Us"
                        }, void 0, false, {
                            fileName: "[project]/src/app/aboutus/page.js",
                            lineNumber: 59,
                            columnNumber: 159
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xl w-1/3 text-center md:text-2xl font-medium mt-4 drop-shadow-[0_4px_6px_rgba(0,0,0,0.6)] text-white",
                            children: "Make world-class mobility accessible to everyone."
                        }, void 0, false, {
                            fileName: "[project]/src/app/aboutus/page.js",
                            lineNumber: 59,
                            columnNumber: 270
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/aboutus/page.js",
                    lineNumber: 59,
                    columnNumber: 78
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 59,
            columnNumber: 10
        }, this);
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "lg:col-span-2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full aspect-video rounded-md overflow-hidden shadow",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                    className: "w-full h-full border-0",
                    src: "https://www.youtube.com/embed/vUKmCcbQFWg",
                    title: "Company Video",
                    allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                    allowFullScreen: true
                }, void 0, false, {
                    fileName: "[project]/src/app/aboutus/page.js",
                    lineNumber: 66,
                    columnNumber: 112
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/aboutus/page.js",
                lineNumber: 66,
                columnNumber: 41
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 66,
            columnNumber: 10
        }, this);
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "max-w-6xl mx-auto px-4 py-12 lg:py-16 grid grid-cols-1 lg:grid-cols-3 gap-8 items-start",
            children: [
                t6,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-sm text-gray-700 space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-2xl font-bold  text-yellow-600",
                            children: "About WellWisher Group"
                        }, void 0, false, {
                            fileName: "[project]/src/app/aboutus/page.js",
                            lineNumber: 73,
                            columnNumber: 172
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "WellWisher Group has proudly stood tall as a leader in Mumbai, Navi Mumbai, and Pune’s real estate development sector for over 15 years. The group commenced operations in 2005 under the able leadership of its dynamic Managing Director Mr. Abhijeet Chandrakant Bhansali."
                        }, void 0, false, {
                            fileName: "[project]/src/app/aboutus/page.js",
                            lineNumber: 73,
                            columnNumber: 251
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Today the group has developed and delivered over 4 million sq. ft across Mumbai, Navi Mumbai, and Pune and has over 1 million sq. ft of spaces currently under development under the guidance of the Managing Director. At WellWisher Group, the customer is the central focus of all our residential and commercial projects."
                        }, void 0, false, {
                            fileName: "[project]/src/app/aboutus/page.js",
                            lineNumber: 73,
                            columnNumber: 527
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "We combine the dual ethos of integrity and aesthetics in building futuristic landmarks and take pride in delivering customer delight."
                        }, void 0, false, {
                            fileName: "[project]/src/app/aboutus/page.js",
                            lineNumber: 73,
                            columnNumber: 852
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/aboutus/page.js",
                    lineNumber: 73,
                    columnNumber: 123
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 73,
            columnNumber: 10
        }, this);
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-4xl md:text-5xl font-extrabold text-center text-yellow-500 tracking-wider mb-14",
            children: "LEADERSHIP"
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t9;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white border border-white/10 shadow-2xl p-6 rounded-2xl",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full relative aspect-[4/5] rounded-xl overflow-hidden shadow-lg",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: "/Abhijeet_Bansal.png",
                    alt: "Abhijeet C Bhansali",
                    fill: true,
                    className: "object-cover"
                }, void 0, false, {
                    fileName: "[project]/src/app/aboutus/page.js",
                    lineNumber: 87,
                    columnNumber: 169
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/aboutus/page.js",
                lineNumber: 87,
                columnNumber: 86
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 87,
            columnNumber: 10
        }, this);
        $[10] = t9;
    } else {
        t9 = $[10];
    }
    let t10;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-3xl font-bold text-white",
                    children: "Abhijeet C Bhansali"
                }, void 0, false, {
                    fileName: "[project]/src/app/aboutus/page.js",
                    lineNumber: 94,
                    columnNumber: 16
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-gray-400 mt-1",
                    children: "Managing Director, WellWisher Group"
                }, void 0, false, {
                    fileName: "[project]/src/app/aboutus/page.js",
                    lineNumber: 94,
                    columnNumber: 86
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 94,
            columnNumber: 11
        }, this);
        $[11] = t10;
    } else {
        t10 = $[11];
    }
    let t11;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-gray-300 text-[15px] leading-relaxed space-y-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "We at WellWisher Group believe that great leaders empower others. Every project undertaken by the group is strongly backed by outstanding leadership, providing invaluable insight and vision that drives the company forward toward greater heights."
                }, void 0, false, {
                    fileName: "[project]/src/app/aboutus/page.js",
                    lineNumber: 101,
                    columnNumber: 80
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Abhijeet Chandrakant Bhansali, MD of WellWisher Group, strives to build a better tomorrow by enhancing lifestyle standards and delivering unmatched quality. With customers at the heart of every endeavor, each project is conceptualized keeping in mind the aspirations, comfort, and satisfaction of the buyer."
                }, void 0, false, {
                    fileName: "[project]/src/app/aboutus/page.js",
                    lineNumber: 101,
                    columnNumber: 332
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 101,
            columnNumber: 11
        }, this);
        $[12] = t11;
    } else {
        t11 = $[12];
    }
    let t12;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "bg-black py-16",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-6xl mx-auto px-4",
                children: [
                    t8,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 lg:grid-cols-3 gap-10 items-start",
                        children: [
                            t9,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "lg:col-span-2 bg-[#111] border border-white/10 shadow-2xl p-8 rounded-2xl text-white space-y-5",
                                children: [
                                    t10,
                                    t11,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "pt-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-48 h-20 relative opacity-90",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                src: "/signature.jpg",
                                                alt: "signature",
                                                fill: true,
                                                className: "object-contain"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/aboutus/page.js",
                                                lineNumber: 108,
                                                columnNumber: 354
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/aboutus/page.js",
                                            lineNumber: 108,
                                            columnNumber: 307
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/aboutus/page.js",
                                        lineNumber: 108,
                                        columnNumber: 285
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/aboutus/page.js",
                                lineNumber: 108,
                                columnNumber: 163
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/aboutus/page.js",
                        lineNumber: 108,
                        columnNumber: 91
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/aboutus/page.js",
                lineNumber: 108,
                columnNumber: 47
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 108,
            columnNumber: 11
        }, this);
        $[13] = t12;
    } else {
        t12 = $[13];
    }
    let t13;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-3xl md:text-4xl font-extrabold text-center text-yellow-600 tracking-wide mb-8",
            children: "SHOWROOM"
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 115,
            columnNumber: 11
        }, this);
        $[14] = t13;
    } else {
        t13 = $[14];
    }
    const t14 = showroomImages[index];
    const t15 = `Showroom ${index + 1}`;
    let t16;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            objectFit: "cover"
        };
        $[15] = t16;
    } else {
        t16 = $[15];
    }
    let t17;
    if ($[16] !== t14 || $[17] !== t15) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-[420px] sm:h-[360px] md:h-[420px] relative",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                src: t14,
                alt: t15,
                fill: true,
                style: t16,
                priority: true
            }, void 0, false, {
                fileName: "[project]/src/app/aboutus/page.js",
                lineNumber: 133,
                columnNumber: 80
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 133,
            columnNumber: 11
        }, this);
        $[16] = t14;
        $[17] = t15;
        $[18] = t17;
    } else {
        t17 = $[18];
    }
    let t18;
    let t19;
    let t20;
    if ($[19] !== index) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2",
            children: showroomImages.map({
                "AboutUsPage[showroomImages.map()]": (_, i_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: {
                            "AboutUsPage[showroomImages.map() > <button>.onClick]": ()=>setIndex(i_0)
                        }["AboutUsPage[showroomImages.map() > <button>.onClick]"],
                        className: `w-2 h-2 rounded-full ${i_0 === index ? "bg-white" : "bg-white/60"}`,
                        "aria-label": `go to slide ${i_0 + 1}`
                    }, i_0, false, {
                        fileName: "[project]/src/app/aboutus/page.js",
                        lineNumber: 145,
                        columnNumber: 58
                    }, this)
            }["AboutUsPage[showroomImages.map()]"])
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 144,
            columnNumber: 11
        }, this);
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: {
                "AboutUsPage[<button>.onClick]": ()=>setIndex((index - 1 + showroomImages.length) % showroomImages.length)
            }["AboutUsPage[<button>.onClick]"],
            className: "absolute left-4 top-1/2 -translate-y-1/2 bg-black/40 text-white p-2 rounded-full hover:bg-black/60",
            "aria-label": "previous",
            children: "‹"
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 149,
            columnNumber: 11
        }, this);
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: {
                "AboutUsPage[<button>.onClick]": ()=>setIndex((index + 1) % showroomImages.length)
            }["AboutUsPage[<button>.onClick]"],
            className: "absolute right-4 top-1/2 -translate-y-1/2 bg-black/40 text-white p-2 rounded-full hover:bg-black/60",
            "aria-label": "next",
            children: "›"
        }, void 0, false, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 152,
            columnNumber: 11
        }, this);
        $[19] = index;
        $[20] = t18;
        $[21] = t19;
        $[22] = t20;
    } else {
        t18 = $[20];
        t19 = $[21];
        t20 = $[22];
    }
    let t21;
    if ($[23] !== t17 || $[24] !== t18 || $[25] !== t19 || $[26] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "bg-white text-gray-800 ",
            children: [
                t5,
                t7,
                t12,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: "py-12",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-w-6xl mx-auto px-4",
                        children: [
                            t13,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative rounded overflow-hidden shadow",
                                children: [
                                    t17,
                                    t18,
                                    t19,
                                    t20
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/aboutus/page.js",
                                lineNumber: 166,
                                columnNumber: 138
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/aboutus/page.js",
                        lineNumber: 166,
                        columnNumber: 93
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/aboutus/page.js",
                    lineNumber: 166,
                    columnNumber: 66
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/aboutus/page.js",
            lineNumber: 166,
            columnNumber: 11
        }, this);
        $[23] = t17;
        $[24] = t18;
        $[25] = t19;
        $[26] = t20;
        $[27] = t21;
    } else {
        t21 = $[27];
    }
    return t21;
}
_s(AboutUsPage, "c3fuAdVwNN91t4bNS1qBXl5hAWY=");
_c = AboutUsPage;
var _c;
__turbopack_context__.k.register(_c, "AboutUsPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_aboutus_page_013b2bba.js.map