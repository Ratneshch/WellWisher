(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_a62874fb._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_0a78009b._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_65e576c2._.js",
  "static/chunks/node_modules_react-icons_gi_index_mjs_657583d5._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/src_app_newcars_page_da50eee5.js"
],
    source: "dynamic"
});
