module.exports = [
"[project]/.next-internal/server/app/aboutus/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_aboutus_page_actions_742b2c9d.js.map