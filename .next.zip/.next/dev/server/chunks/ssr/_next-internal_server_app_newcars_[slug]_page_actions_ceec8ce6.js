module.exports = [
"[project]/.next-internal/server/app/newcars/[slug]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_newcars_%5Bslug%5D_page_actions_ceec8ce6.js.map