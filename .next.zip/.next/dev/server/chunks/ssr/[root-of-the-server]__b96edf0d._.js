module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/data/tatacars.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v(JSON.parse("[{\"id\":1,\"name\":\"TATA SIERRA\",\"slug\":\"tata-sierra\",\"tagline\":\"The Legend Returns\",\"description\":\"Chaos Outside. Calm Within. Welcome Home, in every drive. Your commute, Reimagined.\",\"image\":\"https://s7ap1.scene7.com/is/image/tatamotors/sierra-horses-desktop?$BA-1920-925-D$&fit=fit&fmt=avif-alpha\",\"ytlink\":\"https://www.youtube.com/embed/YLXE-Q37VKo\",\"imageCard\":\"/sierra2.png\",\"color\":\"#F59E0B\",\"accentBg\":\"bg-yellow-500\",\"exShowroom\":\"11.49 Lakh (Expected)\",\"onRoad_Mumbai\":\"13.80 – 14.30 Lakh (Estimated)\",\"specifications\":{\"mileage\":\"16.0 - 18.5 kmpl (Estimated)\",\"engine\":\"1,199 cc / 1.2L turbo petrol (Estimated)\",\"power\":\"≈ 120 PS (Estimated)\",\"torque\":\"≈ 170 Nm (Estimated)\",\"safety\":\"Expected 4-5 Star (Global NCAP) (Estimated)\",\"fuelType\":\"Petrol\",\"transmission\":\"6-speed Manual / AMT (Estimated)\",\"seatingCapacity\":\"5 Seater\",\"bootCapacity\":\"350 L (Estimated)\",\"groundClearance\":\"185 mm (Estimated)\",\"fuelTank\":\"45 L (Estimated)\",\"drivetrain\":\"FWD\",\"suspensionFront\":\"MacPherson Strut\",\"suspensionRear\":\"Torsion Beam / Twist Beam\",\"brakesFront\":\"Disc\",\"brakesRear\":\"Drum/Disc (variant)\",\"tyreSize\":\"195/60 R16 (Estimated)\",\"dimensions\":{\"length\":\"4,200 mm (Estimated)\",\"width\":\"1,770 mm (Estimated)\",\"height\":\"1,620 mm (Estimated)\",\"wheelbase\":\"2,600 mm (Estimated)\"},\"specsSource\":\"Manufacturer previews & media (Estimated)\"}},{\"id\":2,\"name\":\"TATA SAFARI\",\"slug\":\"tata-safari\",\"tagline\":\"Reclaim Your World\",\"description\":\"The Safari is built for those who love adventure and dominance on the road.\",\"image\":\"https://s7ap1.scene7.com/is/image/tatamotors/safari-book-test-drive?$B-1228-488-D$&fit=crop&fmt=avif-alpha\",\"ytlink\":\"https://www.youtube.com/embed/q68H3T3pVlM\",\"imageCard\":\"/safari.png\",\"color\":\"#DAAA5E\",\"accentBg\":\"bg-amber-700\",\"exShowroom\":\"14.66 Lakh\",\"onRoad_Mumbai\":\"17.20 – 18.10 Lakh\",\"specifications\":{\"mileage\":\"14.5 - 17.5 kmpl\",\"engine\":\"1,956 cc / 2.0L Kryotec Diesel\",\"power\":\"170 PS\",\"torque\":\"350 Nm\",\"safety\":\"5 Star (Global NCAP)\",\"fuelType\":\"Diesel\",\"transmission\":\"6-speed Manual / 6-speed Automatic\",\"seatingCapacity\":\"6/7 Seater\",\"bootCapacity\":\"150 - 400 L\",\"groundClearance\":\"200 - 205 mm\",\"fuelTank\":\"50 - 55 L\",\"drivetrain\":\"FWD\",\"suspensionFront\":\"Independent MacPherson Strut\",\"suspensionRear\":\"Multi-link\",\"brakesFront\":\"Ventilated Disc\",\"brakesRear\":\"Disc\",\"tyreSize\":\"215/65 R16 or 215/60 R17\",\"dimensions\":{\"length\":\"4,600 mm\",\"width\":\"1,900 mm\",\"height\":\"1,760 mm\",\"wheelbase\":\"2,741 mm\"},\"specsSource\":\"Tata Motors Official Specs\"}},{\"id\":3,\"name\":\"TATA HARRIER\",\"slug\":\"tata-harrier\",\"tagline\":\"Comfort meets Power\",\"description\":\"A refined SUV with elegant styling and confident road manners.\",\"image\":\"https://s7ap1.scene7.com/is/image/tatamotors/banner-harrier?$B-1228-488-D$&fit=crop&fmt=avif-alpha\",\"ytlink\":\"https://www.youtube.com/embed/9QFe0eELKws\",\"imageCard\":\"/harrier.png\",\"color\":\"#d2c927\",\"accentBg\":\"bg-gray-700\",\"exShowroom\":\"14.99 Lakh\",\"onRoad_Mumbai\":\"17.60 – 18.30 Lakh\",\"specifications\":{\"mileage\":\"14.5 - 17.0 kmpl\",\"engine\":\"1,956 cc / 2.0L Kryotec Diesel\",\"power\":\"170 PS\",\"torque\":\"350 Nm\",\"safety\":\"5 Star (Global NCAP)\",\"fuelType\":\"Diesel\",\"transmission\":\"6-speed Manual / Automatic\",\"seatingCapacity\":\"5 Seater\",\"bootCapacity\":\"425 L\",\"groundClearance\":\"200 - 205 mm\",\"fuelTank\":\"50 - 55 L\",\"drivetrain\":\"FWD\",\"suspensionFront\":\"MacPherson Strut\",\"suspensionRear\":\"Multi-link\",\"brakesFront\":\"Ventilated Disc\",\"brakesRear\":\"Disc\",\"tyreSize\":\"215/60 R17\",\"dimensions\":{\"length\":\"4,600 mm\",\"width\":\"1,894 mm\",\"height\":\"1,706 mm\",\"wheelbase\":\"2,741 mm\"},\"specsSource\":\"Tata Motors Official Data\"}},{\"id\":4,\"name\":\"TATA PUNCH\",\"slug\":\"tata-punch\",\"tagline\":\"Punch Above Its Weight\",\"description\":\"Compact SUV perfect for urban adventures.\",\"image\":\"https://s7ap1.scene7.com/is/image/tatamotors/dealership-banner-new?$B-1228-488-D$&fit=crop&fmt=avif-alpha\",\"ytlink\":\"https://www.youtube.com/embed/smpE8K2ylPw\",\"color\":\"#ff8a65\",\"imageCard\":\"/punchCard.png\",\"exShowroom\":\"6.19 Lakh\",\"onRoad_Mumbai\":\"7.20 – 7.40 Lakh\",\"specifications\":{\"mileage\":\"18.8 to 20.09 kmpl\",\"engine\":\"1,199 cc Revotron Petrol\",\"power\":\"86 PS\",\"torque\":\"113 Nm\",\"safety\":\"5 Star (Global NCAP)\",\"fuelType\":\"Petrol & CNG\",\"transmission\":\"Manual & AMT\",\"seatingCapacity\":\"5 Seater\",\"bootCapacity\":\"366 L\",\"groundClearance\":\"188 mm\",\"fuelTank\":\"37 L\",\"drivetrain\":\"FWD\",\"suspensionFront\":\"MacPherson Strut\",\"suspensionRear\":\"Twist Beam\",\"brakesFront\":\"Disc\",\"brakesRear\":\"Drum\",\"tyreSize\":\"185/65 R15\",\"dimensions\":{\"length\":\"3,840 mm\",\"width\":\"1,742 mm\",\"height\":\"1,606 mm\",\"wheelbase\":\"2,445 mm\"},\"specsSource\":\"Tata Motors Official\"}},{\"id\":5,\"name\":\"TATA TIAGO\",\"slug\":\"tata-tiago\",\"tagline\":\"Smart. Stylish. Safe.\",\"description\":\"A practical hatchback balancing affordability and features.\",\"image\":\"https://s7ap1.scene7.com/is/image/tatamotors/find-dealership-1-1?$B-1228-488-D$&fit=crop&fmt=webp\",\"ytlink\":\"https://www.youtube.com/embed/NRrP1S7LxQE\",\"color\":\"#60a5fa\",\"imageCard\":\"/tiagoCard.png\",\"exShowroom\":\"4.99 Lakh\",\"onRoad_Mumbai\":\"5.80 – 6.10 Lakh\",\"specifications\":{\"mileage\":\"20 - 23 kmpl\",\"engine\":\"1,199 cc Revotron Petrol\",\"power\":\"86 PS\",\"torque\":\"113 Nm\",\"safety\":\"4 Star (Global NCAP)\",\"fuelType\":\"Petrol\",\"transmission\":\"Manual / AMT\",\"seatingCapacity\":\"5 Seater\",\"bootCapacity\":\"242 L\",\"groundClearance\":\"170 - 180 mm\",\"fuelTank\":\"35 L\",\"drivetrain\":\"FWD\",\"suspensionFront\":\"MacPherson Strut\",\"suspensionRear\":\"Twist Beam\",\"brakesFront\":\"Disc\",\"brakesRear\":\"Drum\",\"tyreSize\":\"165/70 R14 / 175/65 R14\",\"dimensions\":{\"length\":\"3,746 mm\",\"width\":\"1,665 mm\",\"height\":\"1,531 mm\",\"wheelbase\":\"2,450 mm\"},\"specsSource\":\"Tata Motors Official\"}},{\"id\":6,\"name\":\"TATA TIGOR\",\"slug\":\"tata-tigor\",\"tagline\":\"Style Meets Substance\",\"description\":\"A compact sedan offering comfortable seating and efficient drivetrains.\",\"image\":\"https://s7ap1.scene7.com/is/image/tatamotors/find-dealership-v1?$B-1228-488-D$&fit=crop&fmt=webp\",\"ytlink\":\"https://www.youtube.com/embed/YLXE-Q37VKo\",\"color\":\"#34d399\",\"imageCard\":\"/tigorCard.png\",\"exShowroom\":\"5.49 Lakh\",\"onRoad_Mumbai\":\"6.40 – 6.70 Lakh\",\"specifications\":{\"mileage\":\"18 - 20 kmpl\",\"engine\":\"1,199 cc Revotron Petrol\",\"power\":\"86 PS\",\"torque\":\"113 Nm\",\"safety\":\"4 Star (Global NCAP)\",\"fuelType\":\"Petrol\",\"transmission\":\"Manual / AMT\",\"seatingCapacity\":\"5 Seater\",\"bootCapacity\":\"419 L\",\"groundClearance\":\"170 mm\",\"fuelTank\":\"35 L\",\"drivetrain\":\"FWD\",\"suspensionFront\":\"MacPherson Strut\",\"suspensionRear\":\"Twist Beam\",\"brakesFront\":\"Disc\",\"brakesRear\":\"Drum\",\"tyreSize\":\"185/65 R15\",\"dimensions\":{\"length\":\"3,990 mm\",\"width\":\"1,672 mm\",\"height\":\"1,535 mm\",\"wheelbase\":\"2,460 mm\"},\"specsSource\":\"Tata Motors Official\"}},{\"id\":7,\"name\":\"TATA ALTROZ\",\"slug\":\"tata-altroz\",\"tagline\":\"Born to Perform\",\"description\":\"A premium hatchback focused on safety, design, and driving dynamics.\",\"image\":\"https://wellwishercars.com/wp-content/uploads/2025/01/pixelcut-export-2-1536x520.png\",\"ytlink\":\"https://www.youtube.com/embed/MIlQe8WmdrE\",\"color\":\"#a78bfa\",\"imageCard\":\"/altrozCard.png\",\"exShowroom\":\"6.30 Lakh\",\"onRoad_Mumbai\":\"7.40 – 7.80 Lakh\",\"specifications\":{\"mileage\":\"18 - 20 kmpl\",\"engine\":\"1,199 cc Revotron Petrol / 1.5L Diesel\",\"power\":\"86 PS (petrol) / 90-110 PS (diesel)\",\"torque\":\"113 Nm (petrol) / 200-220 Nm (diesel)\",\"safety\":\"5 Star (Global NCAP)\",\"fuelType\":\"Petrol / Diesel\",\"transmission\":\"Manual / AMT\",\"seatingCapacity\":\"5 Seater\",\"bootCapacity\":\"345 L\",\"groundClearance\":\"165 - 170 mm\",\"fuelTank\":\"37 L\",\"drivetrain\":\"FWD\",\"suspensionFront\":\"MacPherson Strut\",\"suspensionRear\":\"Twist Beam\",\"brakesFront\":\"Disc\",\"brakesRear\":\"Drum\",\"tyreSize\":\"185/65 R15\",\"dimensions\":{\"length\":\"3,991 mm\",\"width\":\"1,755 mm\",\"height\":\"1,523 mm\",\"wheelbase\":\"2,501 mm\"},\"specsSource\":\"Tata Motors Official / ARAI\"}},{\"id\":8,\"name\":\"TATA NEXON\",\"slug\":\"tata-nexon\",\"tagline\":\"Urban SUV. Boldly Safe.\",\"description\":\"A compact SUV known for strong safety ratings and efficient engines.\",\"image\":\"https://s7ap1.scene7.com/is/image/tatamotors/find-dealership-9?$B-1920-667-D$&fit=crop&fmt=avif-alpha\",\"ytlink\":\"https://www.youtube.com/embed/NHKXwuws2c4\",\"color\":\"#f97316\",\"imageCard\":\"/Nexon.png\",\"accentBg\":\"bg-red-700\",\"exShowroom\":\"7.32 Lakh\",\"onRoad_Mumbai\":\"8.60 – 9.10 Lakh\",\"specifications\":{\"mileage\":\"16 - 20 kmpl\",\"engine\":\"1.2L Turbo Petrol / 1.5L Diesel\",\"power\":\"120 PS (petrol) / 110 PS (diesel)\",\"torque\":\"170 Nm (petrol) / 260 Nm (diesel)\",\"safety\":\"5 Star (Global NCAP)\",\"fuelType\":\"Petrol / Diesel / EV\",\"transmission\":\"Manual / AMT / DCT\",\"seatingCapacity\":\"5 Seater\",\"bootCapacity\":\"350 L\",\"groundClearance\":\"200 - 209 mm\",\"fuelTank\":\"44 L\",\"drivetrain\":\"FWD\",\"suspensionFront\":\"MacPherson Strut\",\"suspensionRear\":\"Twist Beam\",\"brakesFront\":\"Ventilated Disc\",\"brakesRear\":\"Disc / Drum\",\"tyreSize\":\"215/60 R16\",\"dimensions\":{\"length\":\"3,999 mm\",\"width\":\"1,811 mm\",\"height\":\"1,603 mm\",\"wheelbase\":\"2,498 mm\"},\"specsSource\":\"Tata Motors Official\"}},{\"id\":9,\"name\":\"TATA CURVV\",\"slug\":\"tata-curvv\",\"tagline\":\"Style Meets Innovation\",\"description\":\"A futuristic SUV-coupé blending design, performance, and advanced technology.\",\"image\":\"https://cdn.carhp.in/tata/tata_curvv_opera_blue.jpg?format=webp&width=800&q=75\",\"ytlink\":\"https://www.youtube.com/embed/ouNRCGZMtUc\",\"color\":\"#ff4f81\",\"imageCard\":\"/Curvv1.png\",\"accentBg\":\"bg-amber-900\",\"exShowroom\":\"10.50 – 11.50 Lakh (Expected)\",\"onRoad_Mumbai\":\"12.80 – 13.90 Lakh (Estimated)\",\"specifications\":{\"mileage\":\"18 - 20 kmpl (Petrol Estimated)\",\"engine\":\"1.2L Turbo Petrol / EV (Expected)\",\"power\":\"120 - 130 PS (Estimated)\",\"torque\":\"170 - 230 Nm (Estimated)\",\"safety\":\"Expected 4-5 Star (Global NCAP)\",\"fuelType\":\"Petrol / EV\",\"transmission\":\"6-speed Manual / AMT / DCT (Estimated)\",\"seatingCapacity\":\"5 Seater\",\"bootCapacity\":\"360 L (Estimated)\",\"groundClearance\":\"190 - 200 mm (Estimated)\",\"fuelTank\":\"45 L (Estimated)\",\"drivetrain\":\"FWD\",\"suspensionFront\":\"MacPherson Strut (Estimated)\",\"suspensionRear\":\"Twist Beam / Multi-link (Estimated)\",\"brakesFront\":\"Disc\",\"brakesRear\":\"Disc\",\"tyreSize\":\"195/60 R16 or 205/55 R17 (Estimated)\",\"dimensions\":{\"length\":\"4,300 mm (Estimated)\",\"width\":\"1,800 mm (Estimated)\",\"height\":\"1,560 mm (Estimated)\",\"wheelbase\":\"2,600 mm (Estimated)\"},\"specsSource\":\"Manufacturer Previews / Media Estimates\"}}]"));}),
"[project]/src/components/Navbar.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript) <export default as ChevronDown>"); // ICONS
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-ssr] (ecmascript) <export default as ChevronUp>");
// Import your full cars JSON file
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$tatacars$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/data/tatacars.json (json)");
"use client";
;
;
;
;
;
const Navbar = ()=>{
    const navLinks = [
        {
            name: "Home",
            path: "/"
        },
        {
            name: "Cars",
            path: "/newcars"
        },
        {
            name: "About Us",
            path: "/aboutus"
        },
        {
            name: "Contact Us",
            path: "/contactus"
        }
    ];
    // Auto extract id + slug + name
    const carsData = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$tatacars$2e$json__$28$json$29$__["default"].map((car)=>({
            id: car.id,
            slug: car.slug,
            name: car.name
        }));
    const [isScrolled, setIsScrolled] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [isMenuOpen, setIsMenuOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [showDropdown, setShowDropdown] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].useState(false);
    const [mobileDropdown, setMobileDropdown] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].useState(false);
    const hideTimeout = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].useRef(null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].useEffect(()=>{
        const handleScroll = ()=>{
            setIsScrolled(window.scrollY > 20);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
            if (hideTimeout.current) clearTimeout(hideTimeout.current);
        };
    }, []);
    const openDropdown = ()=>{
        if (hideTimeout.current) clearTimeout(hideTimeout.current);
        hideTimeout.current = null;
        setShowDropdown(true);
    };
    const delayedCloseDropdown = (delay = 150)=>{
        if (hideTimeout.current) clearTimeout(hideTimeout.current);
        hideTimeout.current = setTimeout(()=>{
            setShowDropdown(false);
            hideTimeout.current = null;
        }, delay);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: `fixed right-0 inset bg-transparent top-0 mb-5 w-full flex z-50 items-center justify-between px-4 md:px-16 transition-all duration-0 ${isScrolled ? "bg-white text-black" : "bg-linear-to-b from-black/70 via-black/30 text-white"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: "flex items-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "/logo.png",
                            alt: "logo",
                            className: "h-14 md:h-16 cursor-pointer"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Navbar.jsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/Navbar.jsx",
                        lineNumber: 68,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden md:flex gap-10 items-center font-medium",
                        children: [
                            navLinks.map((link)=>link.name === "Cars" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    onMouseEnter: openDropdown,
                                    onMouseLeave: ()=>delayedCloseDropdown(120),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-1 cursor-pointer transition-all duration-300",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: link.path,
                                                    children: link.name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Navbar.jsx",
                                                    lineNumber: 83,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                showDropdown ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                                    size: 18,
                                                    className: "mt-[2px]"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Navbar.jsx",
                                                    lineNumber: 85,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                    size: 18,
                                                    className: "mt-[2px]"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Navbar.jsx",
                                                    lineNumber: 87,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/Navbar.jsx",
                                            lineNumber: 82,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        showDropdown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute top-full left-1/2 -translate-x-1/2 mt-1 bg-white shadow-lg rounded-md w-48 py-2 z-50",
                                            onMouseEnter: openDropdown,
                                            onMouseLeave: ()=>delayedCloseDropdown(120),
                                            children: carsData.map((car)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: `/newcars/${car.slug}`,
                                                    className: "block px-10 py-2 hover:bg-gray-100 text-sm text-gray-700 whitespace-nowrap",
                                                    onClick: ()=>{
                                                        setShowDropdown(false);
                                                        if (hideTimeout.current) {
                                                            clearTimeout(hideTimeout.current);
                                                            hideTimeout.current = null;
                                                        }
                                                    },
                                                    children: car.name
                                                }, car.id, false, {
                                                    fileName: "[project]/src/components/Navbar.jsx",
                                                    lineNumber: 98,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Navbar.jsx",
                                            lineNumber: 92,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, link.name, true, {
                                    fileName: "[project]/src/components/Navbar.jsx",
                                    lineNumber: 76,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: link.path,
                                    className: "transition-all duration-300",
                                    children: link.name
                                }, link.name, false, {
                                    fileName: "[project]/src/components/Navbar.jsx",
                                    lineNumber: 117,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/contactus",
                                    className: `px-5 py-2 bg-amber-500 rounded-2xl font-semibold transition-colors duration-0 ${isScrolled ? "text-black" : "text-white"}`,
                                    children: "Book Test Drive"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Navbar.jsx",
                                    lineNumber: 127,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/Navbar.jsx",
                                lineNumber: 126,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Navbar.jsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "md:hidden text-3xl",
                        onClick: ()=>setIsMenuOpen(!isMenuOpen),
                        children: "☰"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Navbar.jsx",
                        lineNumber: 138,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    isMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-full left-0 w-full bg-white text-black shadow-md py-4 flex flex-col gap-4 font-medium md:hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/",
                                className: "px-6",
                                onClick: ()=>setIsMenuOpen(false),
                                children: "Home"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Navbar.jsx",
                                lineNumber: 148,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "px-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full flex justify-between items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/newcars",
                                                className: "text-left",
                                                onClick: ()=>{
                                                    setIsMenuOpen(false);
                                                    setMobileDropdown(false);
                                                },
                                                children: "Cars"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Navbar.jsx",
                                                lineNumber: 155,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setMobileDropdown(!mobileDropdown),
                                                children: mobileDropdown ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                                    size: 18
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Navbar.jsx",
                                                    lineNumber: 166,
                                                    columnNumber: 37
                                                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                    size: 18
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Navbar.jsx",
                                                    lineNumber: 166,
                                                    columnNumber: 63
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Navbar.jsx",
                                                lineNumber: 165,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Navbar.jsx",
                                        lineNumber: 154,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    mobileDropdown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "pl-4 mt-2 flex flex-col gap-2",
                                        children: carsData.map((car)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: `/newcars/${car.slug}`,
                                                className: "text-sm hover:text-gray-600",
                                                onClick: ()=>{
                                                    setIsMenuOpen(false);
                                                    setMobileDropdown(false);
                                                },
                                                children: car.name
                                            }, car.id, false, {
                                                fileName: "[project]/src/components/Navbar.jsx",
                                                lineNumber: 173,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Navbar.jsx",
                                        lineNumber: 171,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Navbar.jsx",
                                lineNumber: 153,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/aboutus",
                                className: "px-6",
                                onClick: ()=>setIsMenuOpen(false),
                                children: "About Us"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Navbar.jsx",
                                lineNumber: 189,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/contactus",
                                className: "px-6",
                                onClick: ()=>setIsMenuOpen(false),
                                children: "Contact Us"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Navbar.jsx",
                                lineNumber: 192,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Navbar.jsx",
                        lineNumber: 147,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Navbar.jsx",
                lineNumber: 60,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            isMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 md:hidden z-40",
                onClick: ()=>{
                    setIsMenuOpen(false);
                    setMobileDropdown(false);
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Navbar.jsx",
                lineNumber: 201,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = Navbar;
}),
"[project]/src/components/MobDev.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const MobDev = ()=>{
    const handleCallNow = ()=>{
        window.open('tel:+918655627870', '_blank');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3 z-50 md:hidden shadow-lg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/contactus",
                        className: "flex-1 bg-amber-500 text-white py-3 px-4 rounded-full font-semibold text-sm shadow-md hover:shadow-xl transition-all duration-200 flex items-center justify-center",
                        children: "Book Test Drive"
                    }, void 0, false, {
                        fileName: "[project]/src/components/MobDev.jsx",
                        lineNumber: 14,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/contactus",
                        onClick: handleCallNow,
                        className: "flex-1 bg-green-500 text-white py-3 px-4 rounded-full font-semibold text-sm shadow-md hover:shadow-xl transition-all duration-200 flex items-center justify-center",
                        children: "Call Now"
                    }, void 0, false, {
                        fileName: "[project]/src/components/MobDev.jsx",
                        lineNumber: 20,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/MobDev.jsx",
                lineNumber: 13,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/MobDev.jsx",
            lineNumber: 12,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
const __TURBOPACK__default__export__ = MobDev;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b96edf0d._.js.map